var Metis = (function () {
    function Metis(enableHeadlessMetisOption, metisCallbackUrl, enableLocalStorageBoolean, userOfflineByDefault) {
        this.ioQueue = new Object();
        if(enableHeadlessMetisOption == true) {
            this.enableHeadlessMetis = true;
            this.enableLocalStorage = true;
        } else {
            this.enableHeadlessMetis = false;
            if(metisCallbackUrl !== undefined) {
                this.metisCallbackLocation = metisCallbackUrl;
                if(enableLocalStorageBoolean !== undefined) {
                    this.enableLocalStorage = enableLocalStorageBoolean;
                } else {
                    this.enableLocalStorage = false;
                }
            } else {
                console.log("You have defined enableHeadlessMetisOption as FALSE but have NOT provided a callback URL. Expect errors.");
            }
        }
        if(userOfflineByDefault == undefined || false) {
            this.userOnline = true;
        } else {
            this.userOnline = false;
        }
    }
    Metis.prototype.init = function () {
        if(this.enableHeadlessMetis == false) {
            document.addEventListener("online", this.processIOQueue, false);
            document.addEventListener("offline", this.toggleOfflineStatus, false);
        }
    };
    Metis.prototype.objectMerge = function (existingFileContent, newFileContent) {
        for(var objectProperty in newFileContent) {
            if(newFileContent[objectProperty].constructor == Object) {
                if(existingFileContent[objectProperty] !== undefined) {
                    existingFileContent[objectProperty] = this.objectMerge(existingFileContent[objectProperty], newFileContent[objectProperty]);
                } else {
                    existingFileContent[objectProperty] = newFileContent[objectProperty];
                }
            } else {
                existingFileContent[objectProperty] = newFileContent[objectProperty];
            }
        }
        return existingFileContent;
    };
    Metis.prototype.toggleOfflineStatus = function () {
        this.userOnline = false;
    };
    Metis.prototype.processIOQueue = function () {
        var nodeList = Object.getOwnPropertyNames(this.ioQueue);
        this.userOnline = true;
        nodeRecursion:
for(var nodeNum in this.ioQueue) {
            for(var fileName in this.ioQueue[nodeNum]) {
                var fileAction = this.ioQueue[nodeNum][fileName]["action"];
                var contentOrDestinationNodes = this.ioQueue[nodeNum][fileName]["contentOrDestinationNodes"];
                if(this.userOnline == true) {
                    this.fileActionHandler(nodeNum, [
                        fileName
                    ], fileAction, contentOrDestinationNodes);
                    this.ioQueue[nodeNum][fileName] = null;
                } else {
                    break nodeRecursion;
                }
            }
        }
    };
    Metis.prototype.fileActionHandler = function (nodeNum, files, fileAction, contentOrDestinationNodes) {
        var fileContent = new Object();
        var necessaryFilesForRemoteIO = [];
        if(this.enableLocalStorage == true) {
            for(var i = 0; i < files.length; i++) {
                var fileName = files[i];
                var localFileName = nodeNum + "#" + fileName;
                var localFileContent = new Object();
                if(fileAction == ("r" || "a")) {
                    localFileContent = this.decodeJsonFile(localStorage.getItem(localFileName));
                }
                if(fileAction == "r") {
                    if(localFileContent !== null) {
                        if(files.length == 1) {
                            fileContent = localFileContent;
                        } else {
                            fileContent[fileName] = localFileContent;
                        }
                    } else {
                        necessaryFilesForRemoteIO.push(fileName);
                    }
                } else {
                    if(fileAction == "w") {
                        localStorage.setItem(localFileName, JSON.stringify(contentOrDestinationNodes));
                    } else {
                        if(fileAction == "a") {
                            var updatedFileContent = JSON.stringify(this.objectMerge(localFileContent, contentOrDestinationNodes));
                            localStorage.setItem(localFileName, updatedFileContent);
                        } else {
                            if(fileAction == "d") {
                                localStorage.removeItem(localFileName);
                            }
                        }
                    }
                    fileContent[fileName] = this.decodeJsonFile('{"status" : "0.00"}');
                }
            }
        } else {
            necessaryFilesForRemoteIO = files;
        }
        if(this.enableHeadlessMetis == false) {
            if(this.userOnline == true) {
                if((fileAction == "r" && necessaryFilesForRemoteIO.length > 0) || (fileAction !== "r")) {
                    var standardJsonFormData = {
                    };
                    standardJsonFormData.fileAction = fileAction;
                    standardJsonFormData.nodeNum = nodeNum;
                    if(fileAction == "r") {
                        standardJsonFormData.files = necessaryFilesForRemoteIO;
                    } else {
                        standardJsonFormData.files = files;
                    }
                    if(contentOrDestinationNodes !== undefined) {
                        standardJsonFormData.contentOrDestinationNodes = contentOrDestinationNodes;
                    }
                    var metisJSONData = JSON.stringify(standardJsonFormData);
                    var metisXHRManager = new XMLHttpRequest();
                    var metisXHRResponse;
                    function returnMetisContext() {
                        if(metisXHRManager.readyState == 4) {
                            if(metisXHRManager.status == 200) {
                                metisXHRResponse = metisXHRManager.responseText;
                            } else {
                                metisXHRResponse = "HTTP ERROR CODE: " + metisXHRManager.status;
                            }
                        }
                    }
                    metisXHRManager.onreadystatechange = returnMetisContext;
                    metisXHRManager.open("POST", this.metisCallbackLocation, false);
                    metisXHRManager.send(metisJSONData);
                    if(fileAction == "r" && metisXHRResponse.indexOf("HTTP ERROR CODE") == -1) {
                        var remoteFileContent = this.decodeJsonFile(metisXHRResponse);
                        for(var i = 0; i < necessaryFilesForRemoteIO.length; i++) {
                            var fileName = necessaryFilesForRemoteIO[i];
                            if(necessaryFilesForRemoteIO.length == 1) {
                                fileContent[fileName] = remoteFileContent;
                            } else {
                                fileContent[fileName] = remoteFileContent[fileName];
                            }
                            if(this.enableLocalStorage == true) {
                                if(necessaryFilesForRemoteIO.length == 1) {
                                    localStorage.setItem(nodeNum + "#" + fileName, JSON.stringify(remoteFileContent));
                                } else {
                                    localStorage.setItem(nodeNum + "#" + fileName, JSON.stringify(remoteFileContent[fileName]));
                                }
                            }
                        }
                    } else {
                        if(fileAction !== "r") {
                            fileContent = remoteFileContent;
                        }
                    }
                }
            } else {
                if(fileAction !== "r") {
                    necessaryFilesForRemoteIO = files;
                }
                if(necessaryFilesForRemoteIO.length > 0) {
                    for(var i = 0; i < necessaryFilesForRemoteIO.length; i++) {
                        var fileName = necessaryFilesForRemoteIO[i];
                        if(this.ioQueue.hasOwnProperty(nodeNum) == false) {
                            this.ioQueue[nodeNum] = new Object();
                        }
                        if(this.ioQueue[nodeNum].hasOwnProperty(fileName) == false) {
                            this.ioQueue[nodeNum][fileName] = new Object();
                        }
                        this.ioQueue[nodeNum][fileName]["action"] = fileAction;
                        if(fileAction !== ("r" && "d")) {
                            this.ioQueue[nodeNum][fileName]["contentOrDestinationNodes"] = contentOrDestinationNodes;
                        }
                    }
                }
            }
        }
        return JSON.stringify(fileContent);
    };
    Metis.prototype.decodeJsonFile = function (jsonString) {
        return JSON.parse(jsonString);
    };
    Metis.prototype.readJsonFile = function (nodeNum, files) {
        return this.fileActionHandler(nodeNum, files, "r");
    };
    Metis.prototype.createJsonFile = function (nodeNum, files, jsonEncodedContent) {
        return this.fileActionHandler(nodeNum, files, "w", jsonEncodedContent);
    };
    Metis.prototype.updateJsonFile = function (nodeNum, files, jsonEncodedContent, appendContent) {
        if(appendContent == (undefined || false)) {
            return this.fileActionHandler(nodeNum, files, "w", jsonEncodedContent);
        } else {
            return this.fileActionHandler(nodeNum, files, "a", jsonEncodedContent);
        }
    };
    Metis.prototype.deleteJsonFile = function (nodeNum, files) {
        return this.fileActionHandler(nodeNum, files, "d");
    };
    Metis.prototype.replicator = function (nodeNum, nodeDestinations, files) {
        return this.fileActionHandler(nodeNum, files, "rp", nodeDestinations);
    };
    return Metis;
})();
