<?php
	require "php-compressor.php"; // Include the PHP-compressor (code.google.com/p/php-compressor/)
	$PHPCompressor = new Compressor;
	chdir("../"); // Move back a directory

	$metisFrameworkContent = ""; // Declare metisFrameworkContent, which will (as the name implies) be the content of the new framework (class).
	$modules = array("core" => array("fileIO.php", "system.php", "utilities.php")); // Declare $modules as an array of folders and files that need to be compressed

	foreach ($modules as $folderName => $files){
		chdir($folderName); //
	}
?>