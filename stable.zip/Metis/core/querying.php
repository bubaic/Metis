<?php

	function metisQuery($queryString){
		$actionToPerform_FromQuery = substr($queryString, 0, 8); // Get the action to be performed based on the first 6 letters, which is the amount of letters in SELECT, UPDATE and DELETE.
		$validActions = array("SELECT", "UPDATE", "CREATE", "DELETE", "REPLICATE");

		if (atlasui_string_check($actionToPerform_FromQuery, $validActions) == true){ // Check if the first 6 letters in the query string are a valid query action. If so (true)...
			$positionOfBeginningFileSelection = strpos($queryString, "FROM"); // Get the position of the first instance of FROM. It should be noted that any JsonName / JsonValue pair you're getting or updating should NOT include "FROM".
			$jsonNameValueList = substr($queryString, 7, ($positionOfBeginningFileSelection - 7)); // Get the list of jsonName / jsonValue pairs (or if selecting, it'll just be the jsonName) based on the first letters after the 7th position (6 + 1 for whitespace) until FROM position - 7.
			
		}
	}

?>